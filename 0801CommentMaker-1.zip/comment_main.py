import comment_maker.streamlit_views as UI


if __name__ == "__main__":
    UI.main()